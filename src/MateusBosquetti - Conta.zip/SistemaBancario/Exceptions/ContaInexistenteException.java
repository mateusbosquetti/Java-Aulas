package SistemaBancario.Exceptions;

public class ContaInexistenteException extends ContaInvalidaException {
}
