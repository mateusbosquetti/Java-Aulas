package SistemaBancario.Exceptions;

public class SaldoInsuficienteException extends Exception{


}
