package SistemaBancario.Exceptions;

public class ContaInvalidaException extends Exception{
}
