package SistemaBancario.Exceptions;

public class LimiteExcedidoException extends RuntimeException {
}
