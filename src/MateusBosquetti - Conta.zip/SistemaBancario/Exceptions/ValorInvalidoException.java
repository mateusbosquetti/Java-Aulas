package SistemaBancario.Exceptions;

public class ValorInvalidoException extends RuntimeException {
}
