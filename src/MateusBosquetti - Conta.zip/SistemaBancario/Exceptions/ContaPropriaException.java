package SistemaBancario.Exceptions;

public class ContaPropriaException extends ContaInvalidaException{
}
